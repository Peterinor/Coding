/*
 *File		:_max.h
 *Author	:tangyu
 *Date		:2011-05-27 21:00:08 
 *Version	:
 *Modify	:2011-05-27 21:00:16 
 */

#ifndef __MAX_H_
#define __MAX_H_

//#include "max.h"
#include "max.cpp"

#endif
