/*
 *File		:_Exception.h
 *Author	:tangyu
 *Date		:2011-05-27 12:14:59 
 *Version	:1.0.0
 *Modify	:
 */

#ifndef __EXCEPTION_H_
#define __EXCEPTION_H_

#include "Exception.cpp"

#endif
