/*
 *File		:Matrix.h
 *Author	:tangyu
 *Date		:2011-06-02 12:41:46 
 *Version	:1.0.0
 *Modify	:
 */
#ifndef _MATRIX_H_
#define _MATRIX_H_

namespace ty
{
	namespace Math
	{
		class Matrix
		{
		};
	}
}


#endif
