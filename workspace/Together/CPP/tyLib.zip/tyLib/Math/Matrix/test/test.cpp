/*
 *File		:test.cpp
 *Author	:tangyu
 *Date		:2011-05-27 22:09:49 
 *Version	:1.0.0
 *Modify	:
 */

#include <iostream>
using std::cout;
using std::endl;

#include <fstream>
using std::fstream;


#include <string>
using std::string;

#include "../_Matrix.h"

using namespace ty::Math;

int main()
{
	cout<<"Test of Matrix!"<<endl;


	return 0;
}
