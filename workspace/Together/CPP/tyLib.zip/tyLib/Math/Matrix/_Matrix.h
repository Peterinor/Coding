/*
 *File		:_Matrix.h
 *Author	:tangyu
 *Date		:2011-06-02 12:42:07 
 *Version	:1.0.0
 *Modify	:
 */
#ifndef __MATRIX_H_
#define __MATRIX_H_


//#include "Matrix.h"
#include "Matrix.cpp"


#endif
