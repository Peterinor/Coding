

/*
 *File		:_Vector.h
 *Author	:tangyu
 *Date		:2011-06-01 12:40:48 
 *Version	:1.0.0
 *Modify	:2011-06-02 12:40:53 
 */

#ifndef __VECTOR_H_
#define __VECTOR_H_


//#include "Vector.h"
#include "Vector.cpp"


#endif
