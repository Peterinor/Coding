/*
 *File		:_LinkArray.h
 *Author	:tangyu
 *Date		:2011-05-27 22:13:03 
 *Version	:1.0.0
 *Modify	:
 */

#ifndef __LINKARRAY_H_
#define __LINKARRAY_H_

//#include "LinkArray.h"
#include "LinkArray.cpp"


#endif
